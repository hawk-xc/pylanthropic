<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $table    = 'slider';
    protected $fillable = [
        'name',
        'image', 
        'url',
        'sort_number',
        'is_show',
        'created_at',
        'craeted_by',
        'updated_at',
        'updated_by'
    ];
}
